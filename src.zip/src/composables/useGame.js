import { computed, reactive, ref } from "vue";
import { generateSpin } from "../game/trickGenerator.js";
import { FAMILIES, resolveFamily } from "../game/families.js";
import { useCollection } from "./useCollection.js";
import { useSettings } from "./useSettings.js";

// Group mode is S.K.A.T.E with the letters A.I.G.H.T: bail a trick and
// you collect the next letter; five letters and you are out.
export const LETTERS = "BLADE";

// The player who starts a turn may swap the trick this many times
// before attempting it; everyone after them plays the locked-in trick.
export const REROLLS_PER_TURN = 3;

// How many recent grinds solo mode avoids repeating (a sliding window,
// since an endless session cycles through the pool many times).
const SOLO_REPEAT_WINDOW = 15;

const state = reactive({
  screen: "start", // start | game | gameover | sessionReport
  phase: "idle", // idle | spinning | result
  mode: "group", // solo | group
  points: 0, // solo session score
  spinsUsed: 0,
  spinsTotal: 5,
  spin: null, // current generateSpin() result
  spinId: 0, // increments per spin, drives the reel animation
  tricks: [], // landed tricks: { name, orig, score } (solo)
  skipped: [],
  usedGrinds: [],
  newBadges: [], // badges earned by the last landed trick (solo)
  tries: 1, // attempt counter for the trick currently on screen (solo)
  sessionId: null, // current solo session id (see useCollection)
  lastSessionId: null, // shown by the session report screen after ending
  // Set when a session was started from "Grinds to review" (Collection
  // panel) — restricts the Grind/Variation reels to exactly this list
  // of { grindName, variationName } pairs. null in a normal session.
  lockedPairs: null,
  // Set when training a family (see game/families.js) — restricts the
  // draw to that family's entries only, until every one has been
  // landed at least once. Cleared as soon as the family is completed —
  // see familyJustCompleted below, which pauses the session right
  // there instead of silently rolling into something else.
  activeFamilyId: null,
  // Which entry (index into activeFamily.entries) the CURRENT spin drew
  // — a random pick among entries not yet landed, redrawn on every spin
  // (skip included). null when no family is active.
  activeFamilyEntryIndex: null,
  // The family object just finished by the last landTrick() call, or
  // null. While set, the game screen shows a completion pause instead
  // of drawing the next spin automatically — the player explicitly
  // picks "next family" or "keep going free" (see continueFreePlay /
  // nextCareerFamily below) rather than the switch happening unnoticed.
  familyJustCompleted: null,
  // Set instead of familyJustCompleted when the family that just
  // finished was the LAST one of its whole Career track — triggers the
  // full-screen CareerCompleteScreen (state.screen = "careerComplete")
  // rather than the regular pause panel. { track, badge } | null.
  careerJustCompleted: null,

  // group (S.K.A.T.E) state
  players: [], // { name, letters }
  round: 0,
  turnOrder: [], // player indices attempting the current trick, in order
  turnPos: 0, // position within turnOrder
  rerollsLeft: 0, // trick swaps the turn's starting player has left
});

const collection = useCollection();
const settingsApi = useSettings();

// Resolves either a built-in family (families.js) or a player-built one
// (settings.customFamilies) by id — see resolveFamily in families.js.
// Named settingsApi (not settings) so it never shadows the `settings`
// parameter most functions below already take from their own caller.
function resolveFamilyById(familyId) {
  return familyId ? resolveFamily(familyId, settingsApi.settings.customFamilies) : null;
}

// Undo, for a mistapped Blade!/Passer/Loupé/Réussi — a full snapshot of
// both state and the collection right before the action mutates
// anything, restored wholesale rather than trying to surgically
// reverse each individual side effect (score, family progress, badges,
// session counts, streak...). Simpler and far less error-prone than
// hand-unwinding all of that, and cheap enough at this app's scale.
// Single-level only: taking a new snapshot overwrites the old one, and
// it's cleared outright whenever a session starts/ends, so there's
// never a stale snapshot from a different session to accidentally
// restore.
let undoSnapshot = ref(null);

function captureUndoSnapshot() {
  undoSnapshot.value = {
    state: JSON.parse(JSON.stringify(state)),
    collection: JSON.parse(JSON.stringify(collection.collection)),
  };
}

function clearUndoSnapshot() {
  undoSnapshot.value = null;
}

const canUndo = computed(() => undoSnapshot.value !== null);

function undoLastAction() {
  if (!undoSnapshot.value) {
    return;
  }
  Object.assign(state, undoSnapshot.value.state);
  Object.assign(collection.collection, undoSnapshot.value.collection);
  undoSnapshot.value = null;
}

const activeIndices = () =>
  state.players
    .map((player, index) => ({ player, index }))
    .filter(({ player }) => player.letters < LETTERS.length)
    .map(({ index }) => index);

export function useGame() {
  const spinsLeft = computed(() => state.spinsTotal - state.spinsUsed);
  const isSolo = computed(() => state.mode === "solo");
  const currentPlayer = computed(() =>
    state.mode === "group" && state.turnOrder.length > state.turnPos
      ? state.players[state.turnOrder[state.turnPos]]
      : null
  );
  // The current player bails out of the game with one more letter.
  const onLastLetter = computed(
    () => (currentPlayer.value?.letters ?? 0) === LETTERS.length - 1
  );
  const activeFamily = computed(() => resolveFamilyById(state.activeFamilyId));

  // Switching what you're training (Custom, a family, review mode, a
  // different family...) used to always start a brand new session,
  // fragmenting Historique into lots of near-empty rows every time you
  // changed your mind mid-sitting. Now it only truly starts fresh if
  // there's no session already open — otherwise everything you do
  // before actually tapping "Terminer la session" keeps accumulating
  // into that same one. Returns true if this call started a fresh one.
  function beginOrContinueSoloSession() {
    const isFresh = !state.sessionId;
    if (isFresh) {
      state.points = 0;
      state.spinsUsed = 0;
      state.tricks = [];
      state.skipped = [];
      state.usedGrinds = [];
      state.newBadges = [];
      state.sessionId = collection.startSession();
      clearUndoSnapshot();
    }
    return isFresh;
  }

  const startGame = (settings, mode = settings.mode || "group") => {
    state.mode = mode;
    state.activeFamilyId = null;
    state.activeFamilyEntryIndex = null;
    state.familyJustCompleted = null;
    state.careerJustCompleted = null;
    state.lockedPairs = null;
    state.screen = "game";

    if (mode === "solo") {
      state.spinsTotal = Infinity;
      beginOrContinueSoloSession();
      nextSpin(settings);
      return;
    }

    // Group mode always starts a clean slate — and closes out any solo
    // session left dangling open rather than abandoning it silently.
    if (state.sessionId) {
      collection.endSession(state.sessionId);
      state.sessionId = null;
    }
    state.points = 0;
    state.spinsUsed = 0;
    state.tricks = [];
    state.skipped = [];
    state.usedGrinds = [];
    state.newBadges = [];
    state.players = settings.players.map((name, i) => ({
      name: String(name).trim() || `Player ${i + 1}`,
      letters: 0,
    }));
    state.round = 0;
    beginRound(settings);
  };

  /**
   * Solo only: same as startGame, but the Grind/Variation reels are
   * restricted to exactly the given { grindName, variationName } pairs
   * for the whole session — used by "Grinds to review" in the
   * Collection panel to deliberately drill neglected combos.
   */
  const startReviewSession = (pairs, settings) => {
    state.mode = "solo";
    state.lockedPairs = pairs;
    state.activeFamilyId = null;
    state.activeFamilyEntryIndex = null;
    state.familyJustCompleted = null;
    state.careerJustCompleted = null;
    state.screen = "game";
    state.spinsTotal = Infinity;
    beginOrContinueSoloSession();
    nextSpin(settings);
  };

  /**
   * Solo only: family training (see game/families.js). Each spin draws
   * a random entry among the family's tricks not yet landed — skipping
   * doesn't block anything, it just redraws; landing removes that entry
   * from the pool for good. Resumes where you left off unless `restart`
   * is set (or the family was already fully complete, in which case it
   * restarts anyway).
   */
  const startFamilySession = (familyId, settings, { restart = false } = {}) => {
    state.mode = "solo";
    state.lockedPairs = null;
    state.activeFamilyId = familyId;
    state.activeFamilyEntryIndex = null;
    state.familyJustCompleted = null;
    state.careerJustCompleted = null;
    if (restart || collection.isFamilyComplete(familyId)) {
      collection.resetFamilyProgress(familyId);
    }
    state.screen = "game";
    state.spinsTotal = Infinity;
    beginOrContinueSoloSession();
    nextSpin(settings);
  };

  // One round = one trick that every player still in the game attempts.
  // The starting player rotates each round and gets fresh rerolls.
  const beginRound = (settings) => {
    state.round += 1;
    const active = activeIndices();
    const start = (state.round - 1) % active.length;
    state.turnOrder = [...active.slice(start), ...active.slice(0, start)];
    state.turnPos = 0;
    state.rerollsLeft = REROLLS_PER_TURN;
    nextSpin(settings);
  };

  /**
   * Group: the starting player swaps the trick for a fresh spin. Only
   * possible before anyone attempted it, and at most 3 times per turn.
   */
  const rerollTrick = (settings) => {
    if (state.mode !== "group" || state.turnPos !== 0 || state.rerollsLeft <= 0) {
      return;
    }
    state.rerollsLeft -= 1;
    nextSpin(settings);
  };

  const nextSpin = (settings) => {
    state.spinsUsed += 1;
    state.tries = 1;
    // Solo trains you: never-landed and often-skipped grinds come up more.
    const bias = state.mode === "solo" ? collection.grindBias() : null;
    const family = resolveFamilyById(state.activeFamilyId);
    let forcedTrick = null;
    if (family) {
      const remaining = collection.familyRemainingIndices(
        state.activeFamilyId,
        family.entries
      );
      // Should only be empty for one frame right as the family
      // completes (landTrick clears activeFamilyId before this runs) —
      // guarded here anyway rather than crashing.
      if (remaining.length) {
        state.activeFamilyEntryIndex =
          remaining[Math.floor(Math.random() * remaining.length)];
        forcedTrick = family.entries[state.activeFamilyEntryIndex];
      } else {
        state.activeFamilyEntryIndex = null;
      }
    } else {
      state.activeFamilyEntryIndex = null;
    }
    state.spin = generateSpin(
      settings.tricks,
      state.usedGrinds,
      bias,
      settings.grinds,
      settings.switchUpGrinds,
      state.lockedPairs,
      forcedTrick
    );
    state.usedGrinds.push(
      state.spin.reels.find((r) => r.name === "Grind").winner.name
    );
    const switchUpReel = state.spin.reels.find((r) => r.name === "SwitchUp");
    if (switchUpReel && switchUpReel.winner) {
      state.usedGrinds.push(switchUpReel.winner.name);
    }
    if (state.mode === "solo" && state.usedGrinds.length > SOLO_REPEAT_WINDOW) {
      state.usedGrinds.shift();
    }
    state.spinId += 1;
    state.phase = "spinning";
  };

  // Called by the slot machine once every reel has stopped.
  const onReelsSettled = () => {
    state.phase = "result";
  };

  // Solo: one more failed real-life attempt at the trick on screen.
  // Doesn't touch the spin — same trick, just counts the try.
  const addTry = () => {
    state.tries += 1;
  };

  const currentTrick = () => ({
    name: state.spin.name,
    orig: state.spin.orig,
    score: state.spin.score,
  });

  /** Group: resolve the current player's attempt at the round's trick. */
  const attempt = (landed, settings) => {
    const player = state.players[state.turnOrder[state.turnPos]];
    if (!landed) {
      player.letters += 1;
      // A bail on the last letter can decide the game mid-round: with
      // one player left standing, later attempts this round are moot.
      if (activeIndices().length <= 1) {
        endGame();
        return;
      }
    }
    if (state.turnPos + 1 < state.turnOrder.length) {
      state.turnPos += 1; // same trick, next player
      return;
    }
    // Classic S.K.A.T.E: rounds go on until one player is left standing.
    if (activeIndices().length <= 1) {
      endGame();
    } else {
      beginRound(settings);
    }
  };

  const landTrick = (settings) => {
    captureUndoSnapshot();
    state.points += state.spin.score;
    state.tricks.push(currentTrick());
    const activeFamilyForLand = state.activeFamilyId
      ? resolveFamilyById(state.activeFamilyId)
      : null;
    const activeEntryForLand =
      activeFamilyForLand && state.activeFamilyEntryIndex !== null
        ? activeFamilyForLand.entries[state.activeFamilyEntryIndex]
        : null;
    let badges =
      state.mode === "solo"
        ? collection.recordLand(
            state.spin,
            state.tries,
            state.sessionId,
            state.activeFamilyId,
            activeEntryForLand
          )
        : [];
    let justCompletedFamily = null;
    if (state.activeFamilyId) {
      const family = activeFamilyForLand;
      if (family && state.activeFamilyEntryIndex !== null) {
        const familyBadge = collection.advanceFamilyProgress(
          family,
          family.entries[state.activeFamilyEntryIndex]
        );
        if (familyBadge) {
          badges = [...badges, familyBadge];
        }
        if (collection.isFamilyComplete(state.activeFamilyId)) {
          justCompletedFamily = family;
          state.activeFamilyId = null;
          state.activeFamilyEntryIndex = null;
        }
      }
    }
    state.newBadges = badges;
    if (justCompletedFamily) {
      // The last family of a whole Career track finishing is a bigger
      // moment than a regular one — it gets its own full-screen
      // takeover instead of the usual pause-and-pick panel, since
      // there's no "next family" to offer anyway.
      const careerBadge = justCompletedFamily.track
        ? collection.awardCareerBadgeIfComplete(justCompletedFamily.track)
        : null;
      if (careerBadge) {
        state.careerJustCompleted = {
          track: justCompletedFamily.track,
          badge: careerBadge,
        };
        state.screen = "careerComplete";
        return;
      }
      // Pause here — don't draw a next (unrelated) spin until the
      // player explicitly chooses what happens next.
      state.familyJustCompleted = justCompletedFamily;
      return;
    }
    nextSpin(settings);
  };

  /** The next family in career order after this one (same track, next
   * tier), or null if it was the last one. */
  const nextFamilyInOrder = (family) =>
    FAMILIES.find((f) => f.track === family.track && f.tier === family.tier + 1) ||
    null;

  // Player's choice after a family completion pause: keep the session
  // going as normal free solo play (what used to happen automatically).
  const continueFreePlay = (settings) => {
    state.familyJustCompleted = null;
    state.careerJustCompleted = null;
    nextSpin(settings);
  };

  // Player's choice after a family completion pause: jump straight into
  // training the next family in career order (same track). No-ops if
  // there isn't one (shouldn't be reachable from the UI in that case).
  const nextCareerFamily = (settings) => {
    const completed = state.familyJustCompleted;
    if (!completed) {
      return;
    }
    const next = nextFamilyInOrder(completed);
    state.familyJustCompleted = null;
    state.careerJustCompleted = null;
    if (next) {
      startFamilySession(next.id, settings);
    } else {
      nextSpin(settings);
    }
  };

  const skipTrick = (settings) => {
    captureUndoSnapshot();
    state.skipped.push(currentTrick());
    if (state.mode === "solo") {
      const family = state.activeFamilyId ? resolveFamilyById(state.activeFamilyId) : null;
      const entry =
        family && state.activeFamilyEntryIndex !== null
          ? family.entries[state.activeFamilyEntryIndex]
          : null;
      collection.recordSkip(state.spin, state.sessionId, state.activeFamilyId, entry);
    }
    nextSpin(settings);
  };

  const endGame = () => {
    state.screen = "gameover";
    state.phase = "idle";
  };

  // Solo sessions have no game over: ending one shows the session
  // report instead of just bouncing back to the start screen.
  const giveUp = () => {
    clearUndoSnapshot();
    if (state.mode === "solo") {
      if (state.sessionId) {
        collection.endSession(state.sessionId);
        state.lastSessionId = state.sessionId;
        state.sessionId = null;
      }
      state.screen = "sessionReport";
      state.phase = "idle";
    } else {
      endGame();
    }
  };

  const goToStart = () => {
    state.screen = "start";
    state.phase = "idle";
    state.spin = null;
    state.newBadges = [];
    state.careerJustCompleted = null;
  };

  /**
   * There's no way to run code while the app is closed, so "at
   * midnight" really means "next time the Start screen is shown" — if
   * a solo session was left dangling open from a PREVIOUS calendar day
   * (forgot to tap "Terminer la session"), it's quietly closed out
   * here instead of silently growing forever. A session still open
   * from TODAY is left alone — jumping back into it is likely, and the
   * Start screen offers its own manual "Terminer" button for that case
   * (see hasOpenSessionToday below).
   */
  function closeStaleSessionIfNeeded() {
    if (!state.sessionId) {
      return;
    }
    const session = collection.sessionById(state.sessionId);
    if (!session) {
      state.sessionId = null;
      return;
    }
    const startedDay = session.startedAt.slice(0, 10);
    const today = new Date().toISOString().slice(0, 10);
    if (startedDay !== today) {
      collection.endSession(state.sessionId);
      state.lastSessionId = state.sessionId;
      state.sessionId = null;
    }
  }

  const hasOpenSessionToday = computed(() => state.sessionId !== null);

  /** Manual escape hatch from the Start screen for a same-day session
   * left open (didn't want to lose it automatically, but also don't
   * want to jump back into it right now). */
  function endOpenSession() {
    if (state.sessionId) {
      giveUp();
    }
  }

  return {
    state,
    spinsLeft,
    isSolo,
    currentPlayer,
    onLastLetter,
    startGame,
    startReviewSession,
    startFamilySession,
    activeFamily,
    onReelsSettled,
    attempt,
    rerollTrick,
    landTrick,
    skipTrick,
    canUndo,
    undoLastAction,
    nextFamilyInOrder,
    continueFreePlay,
    nextCareerFamily,
    addTry,
    giveUp,
    goToStart,
    closeStaleSessionIfNeeded,
    hasOpenSessionToday,
    endOpenSession,
  };
}